@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
set "REG_KEY=HKCU\SOFTWARE\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location6"
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
reg add "%REG_KEY%" /v "Path"            /t REG_SZ    /d "%SCRIPT_DIR%\\"        /f >nul 2>&1
reg add "%REG_KEY%" /v "AllowSubfolders" /t REG_DWORD /d 1                        /f >nul 2>&1
reg add "%REG_KEY%" /v "Description"     /t REG_SZ    /d ""                       /f >nul 2>&1
reg add "%REG_KEY%" /v "Date"            /t REG_SZ    /d "01/01/2026 12:00"       /f >nul 2>&1
echo.
echo ��װ���
pause >nul
exit